# kitten-game-auto-observe
